'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n=int(input())
flag=0
for i in range(2,n):
 if i**2==n:
  flag=1
 
if flag==1:
 print(n,"is perfect square")
else:
 print("not perfect square")