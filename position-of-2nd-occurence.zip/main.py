'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

 
def getIndex(l,n2):
 l.remove(n2)
 print(l.index(n2)+1)
 
l=[]
n=int(input())
for i in range(n):
 n1=int(input())
 l.append(n1)
n2=int(input())
getIndex(l,n2)