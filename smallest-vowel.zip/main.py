'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
s=input()
l=[]
for i in s.lower():
    if i=="a" or i=="e" or i=="i" or i=="o" or i=="u":
        l.append(i)
l.sort()
print(l[0])