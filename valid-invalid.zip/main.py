'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

n=int(input())
l=[]
for i in range(n):
    e=input()
    l.append(e)

CV=0
IV=0


for i in l:
    if i.isalpha() or " " in i:
        CV=CV+1
    else:
        IV=IV+1
   
print("CV",CV)
print("IV",IV)
        
        
    
