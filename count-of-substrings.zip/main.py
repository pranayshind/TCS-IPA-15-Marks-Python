'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n=int(input())
l=[]
for i in range(n):
    e=input()
    a=e.split()
    l.append(a)

s=input()
c=0
for j in l:
    for k in j:
        if k.lower()==s.lower():
            c=c+1
if c!=0:
    print(c)
else:
    print("no string found")