'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n=int(input())
a=str(n)
l=[]
for i in a:
    l.append(i)
    
li=list(map(int,l))
b=sum(li)
if b%3==0:
    print("True")
else:
    print("False")