'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def validscore(n):
 if 100>=n>0:
  return True
 else:
  return False

def findvalidscores(l):
 l1=[]
 for i in l:
  if validscore(i)==True:
   l1.append(i)
 if l1==[]:
  print("No valid score found")
 else:
  print(l1)
  
n1=int(input())
l=[]
for i in range(n1):
 e=int(input())
 l.append(e)

findvalidscores(l)